package Malosi.Book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MalosiBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(MalosiBookApplication.class, args);
	}

}
