package Malosi.Book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MalosiBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
